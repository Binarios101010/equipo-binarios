<?php

class conectar{
    private $servidor="localhost";
    private $usuario="medina";
    private $password="medina";
    private $bd="inai";

    public function conexion(){
        $conexion=mysqli_connect($this->servidor,
            $this->usuario,
            $this->password,
            $this->bd);
        return $conexion;
    }
}


?>