<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
include 'conexion.php';

$getData= "select * from declaracion_patrimonial";
$qur = $connection->query($getData);

while($r = mysqli_fetch_assoc($qur)){
    $msg[] = array("Iddeclaracion"=>$r['Iddeclaracion'], "Ejercicio"=>$r['Ejercicio'],
        "Fecha_Inicio_Periodo_Informa"=>$r['Fecha_Inicio_Periodo_Informa'], "Fecha_Termino_Periodo_Informa"=>$r['Fecha_Termino_Periodo_Informa'],
        "Tipo_Integrante_Del_Sujeto"=>$r['Tipo_Integrante_Del_Sujeto'],"Clave_O_Nivel_Puesto"=>$r['Clave_O_Nivel_Puesto'],
        "Denominacion_Puesto"=>$r['Denominacion_Puesto'],
        "Denominacion_Cargo"=>$r['Denominacion_Cargo'],
        "Area_Adscripcion"=>$r['Area_Adscripcion'],
        "Nombre_Servidor_Publico"=>$r['Nombre_Servidor_Publico'],
        "Primer_Apellido_Servidor"=>$r['Primer_Apellido_Servidor'],
        "Segundo_Apellido_Servidor"=>$r['Segundo_Apellido_Servidor'],
        "Modalidad_Declaracion_Patrimonial"=>$r['Modalidad_Declaracion_Patrimonial'],
        "Hipervinculo_Version_Publica"=>$r['Hipervinculo_Version_Publica'],
        "Areas_Responsable_Genera_Poseen_Publican"=>$r['Areas_Responsable_Genera_Poseen_Publican'],
        "Fecha_Validacion"=>$r['Fecha_Validacion'],
        "Fecha_Actualizacion"=>$r['Fecha_Actualizacion']
        );
}
$datos=$msg;
header('content-type: application/json');
echo json_encode($datos);
@mysqli_close($conexion);

?>

