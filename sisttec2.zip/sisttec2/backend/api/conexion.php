<?php
$connection = new mysqli("localhost","root","","inai") or die(mysqli_error());
?>