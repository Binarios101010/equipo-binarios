<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Speech Detection</title>

</head>
<body>

  <div class="words" contenteditable>
  </div>
  <button id="campo" onclick="mostrar()">Buscar</button>
<script type="text/javascript">
  function mostrar(){
  var campo = document.getElementsByTagName("p");
  var etiqueta =campo[0].innerHTML;
  if (etiqueta == "Morelos") {
    window.location="morelos.php";
  }else{
    alert("No definido");
  }
  }
</script>
<script>
  window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  const recognition = new SpeechRecognition();
  recognition.interimResults = true;
  recognition.lang = 'es-MX';

  let p = document.createElement('p');
  /*var element = document.createElement("div");
element.id = 'testqq';
var el = document.getElementById('testqq');*/
  p.id = 'rt';
  const words = document.querySelector('.words');
  words.appendChild(p);

  recognition.addEventListener('result', e => {
    const transcript = Array.from(e.results)
      .map(result => result[0])
      .map(result => result.transcript)
      .join('');

      const poopScript = transcript.replace(/poop|poo|shit|dump/gi, '💩');
      p.textContent = poopScript;

      if (e.results[0].isFinal) {
        p = document.createElement('p');
        words.appendChild(p);
      }
  });

  recognition.addEventListener('end', recognition.start);

  recognition.start();

</script>


  <style>
    html {
      font-size: 10px;
    }

    body {
      background: white;
      font-family: 'helvetica neue';
      font-weight: 200;
      font-size: 20px;
    }

    .words {
      max-width: 500px;
      margin: 50px auto;
      background: white;
    }

    p {
      margin: 0 0 3rem;
    }

    .words:before {
      content: '';
      position: absolute;
      width: 4px;
      top: 0;
      left: 30px;
      bottom: 0;
      border: 1px solid;
      border-color: gray;
    }
  </style>

</body>
</html>
